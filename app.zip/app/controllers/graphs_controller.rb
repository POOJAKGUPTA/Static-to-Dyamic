class GraphsController < ApplicationController
  def flot
  end

  def morris
  end

  def rickshaw
  end

  def chartjs
  end

  def chartist
  end

  def peity
  end

  def sparkline
  end

  def c3charts
  end

end
