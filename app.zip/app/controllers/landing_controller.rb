class LandingController < ApplicationController
  def index
    render :layout => "empty"
  end

end