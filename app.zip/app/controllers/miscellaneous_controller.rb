class MiscellaneousController < ApplicationController
  def google_maps
  end

  def codee_ditor
  end

  def modal_window
  end

  def nestablelist
  end

  def validation
  end

  def notification
  end

  def timeline_second_version
  end

  def forum_view
  end

  def forum_post_view
  end

  def tree_view
  end

  def chat_view
  end

  def agile_board
  end

  def diff
  end

  def sweet_alert
  end

  def idle_timer
  end

  def spinners
  end

  def live_favicon
  end

  def masonry
  end

  def loading_buttons
  end

  def clipboard
  end

  def tour
  end

  def truncate
  end

  def i18support
  end

  def masonry
  end

  def masonry
  end

end
