class WidgetsController < ApplicationController
  def index
  end

end
