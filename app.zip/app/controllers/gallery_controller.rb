class GalleryController < ApplicationController
  def basic_gallery
  end

  def bootstrap_carusela
  end

  def slick_carusela
  end

end
