class FormsController < ApplicationController
  def basic_forms
  end

  def advanced
  end

  def wizard
  end

  def file_upload
  end

  def text_editor
  end

  def markdown
  end

end
