class GridoptionsController < ApplicationController
  def index
  end

end
