class TablesController < ApplicationController
  def static_tables
  end

  def data_tables
  end

  def foo_tables
  end

  def jqgrid
  end

end
