class CssanimationsController < ApplicationController
  def index
  end

end
