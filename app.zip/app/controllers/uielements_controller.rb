class UielementsController < ApplicationController
  def typography
  end

  def icons
  end

  def draggable_panels
  end

  def resizeable_panels
  end

  def buttons
  end

  def tables_panels
  end

  def tabs
  end

  def notifications_tooltips
  end

  def badges_labels_progress
  end

  def video
  end

end
