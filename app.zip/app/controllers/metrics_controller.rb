class MetricsController < ApplicationController
  def index
  end

end
