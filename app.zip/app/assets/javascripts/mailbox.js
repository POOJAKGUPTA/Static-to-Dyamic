//= require iCheck/icheck.min.js
//= require summernote/summernote.min.js