//= require blueimp/jquery.blueimp-gallery.min.js
//= require slick/slick.min.js