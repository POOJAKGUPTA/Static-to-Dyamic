//= require footable/footable.all.min.js
//= require slick/slick.min.js